"""
Prompt templates and utilities for the Apex Arena.

The templates include instructions for using answer tags and problem-specific instructions.
"""

import os
from pathlib import Path
from typing import Any, Dict

import yaml

BASE_DIR = os.environ.get("BASE_DIR", "/mcp_server")

TEMPLATE = """If the question asks for a solution, enclose your final solution within answer tags: <answer>(your solution)</answer>. This
will also end the conversation. \
Only code between the very first set of answer tags will be graded, so make sure you're as certain as \
possible about your solution before writing it out with answer tags! If imports are required, \
make sure to include them inside the tags as well.

Otherwise, just output "<DONE>" to end the conversation when you're done with the task that you were assigned. \

Here is the problem I want you to solve:
<problem>
<STATEMENT>
</problem>

Note: your working directory is /workdir.
"""

PROBLEM_TEMPLATES = {
    "git": """You are given a Git repository with specific tasks to perform. Your solution should be a series of Git commands that accomplish the task.
Make sure to test your commands before submitting the final solution.

Example Git commands:
<toy_script>
git log --oneline  # View commit history
git rebase -i HEAD~2  # Interactive rebase of last 2 commits
git commit --amend --author="New Author <new@example.com>"  # Change commit author
</toy_script>
""",
    "python": """You are given a Python programming problem. Your solution should be a Python script that solves the problem.
Make sure to include all necessary imports and handle edge cases.

Example Python script:
<toy_script>
def solve_problem(input_data):
    # Process input
    result = process_data(input_data)
    return result

if __name__ == "__main__":
    input_data = input()
    print(solve_problem(input_data))
</toy_script>
""",
    "shell": """You are given a shell scripting problem. Your solution should be a series of shell commands or a shell script that accomplishes the task.
Make sure to handle errors and edge cases appropriately.

Example shell commands:
<toy_script>
#!/bin/bash
# Process files
for file in *.txt; do
    if [ -f "$file" ]; then
        process_file "$file"
    fi
done
</toy_script>
""",
}


def get_problem_template(problem_type: str) -> str:
    return PROBLEM_TEMPLATES.get(problem_type, "")


def load_problem_prompt(problem_id: str) -> str:
    problem_path = Path(BASE_DIR) / "tasks" / problem_id / "task.yaml"
    if not problem_path.exists():
        raise ValueError(f"Problem {problem_id} not found")

    with open(problem_path) as f:
        task_data = yaml.safe_load(f)

    problem_type = task_data.get("metadata", {}).get("category", "python")

    prompt = get_problem_template(problem_type)
    prompt += "\n\n" + TEMPLATE

    return prompt.replace("<STATEMENT>", task_data["prompt"])


def get_problem_metadata(problem_id: str) -> Dict[str, Any]:
    problem_path = Path(BASE_DIR) / "tasks" / problem_id / "task.yaml"
    if not problem_path.exists():
        raise ValueError(f"Problem {problem_id} not found")

    with open(problem_path) as f:
        task_data = yaml.safe_load(f)

    return task_data.get("metadata", {})
