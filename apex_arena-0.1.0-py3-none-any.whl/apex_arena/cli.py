import asyncio
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.markup import escape
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Confirm, Prompt
from rich.syntax import Syntax
from rich.table import Table

console = Console()

APEX_ASCII_ART = """
    █████╗ ██████╗ ███████╗██╗  ██╗    █████╗ ██████╗ ███████╗███╗   ██╗ █████╗ 
   ██╔══██╗██╔══██╗██╔════╝╚██╗██╔╝   ██╔══██╗██╔══██╗██╔════╝████╗  ██║██╔══██╗
   ███████║██████╔╝█████╗   ╚███╔╝    ███████║██████╔╝█████╗  ██╔██╗ ██║███████║
   ██╔══██║██╔═══╝ ██╔══╝   ██╔██╗    ██╔══██║██╔══██╗██╔══╝  ██║╚██╗██║██╔══██║
   ██║  ██║██║     ███████╗██╔╝ ██╗   ██║  ██║██║  ██║███████╗██║ ╚████║██║  ██║
   ╚═╝  ╚═╝╚═╝     ╚══════╝╚═╝  ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═══╝╚═╝  ╚═╝
"""

WELCOME_MESSAGE = """
Welcome to Apex Arena! 🚀

Apex Arena is a platform for testing and evaluating your challenging problems with the "Bigfoot".
Here's what you can do:

1. [bold cyan]Setup[/bold cyan] - Configure your environment and start the MCP server
2. [bold green]Grade[/bold green] - Test and grade specific problem
3. [bold yellow]Eval[/bold yellow] - Run evaluations across multiple tasks and aggregate results

Choose an option to get started!
"""


def check_docker_image_exists(image_name: str) -> bool:
    """Check if a Docker image exists."""
    result = subprocess.run(
        ["docker", "images", "-q", image_name], capture_output=True, text=True
    )
    return bool(result.stdout.strip())


def check_docker_network_exists(network_name: str) -> bool:
    """Check if a Docker network exists."""
    result = subprocess.run(
        ["docker", "network", "ls", "-q", "-f", f"name={network_name}"],
        capture_output=True,
        text=True,
    )
    return bool(result.stdout.strip())


def create_restricted_network():
    """Create the restricted Docker network if it doesn't exist."""
    network_name = "restricted_net"

    if check_docker_network_exists(network_name):
        console.print(f"[green]Docker network '{network_name}' already exists[/green]")
        return

    console.print(f"[yellow]Creating Docker network '{network_name}'...[/yellow]")

    cmd = [
        "docker",
        "network",
        "create",
        "--driver",
        "bridge",
        "--opt",
        "com.docker.network.bridge.enable_ip_masquerade=false",
        "--subnet",
        "172.31.0.0/16",
        network_name,
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        console.print(f"[red]Error creating Docker network: {result.stderr}[/red]")
        sys.exit(1)

    console.print(
        f"[green]Docker network '{network_name}' created successfully![/green]"
    )


def check_task_dockerfile(problem_id: str) -> bool:
    """Check if a task-specific Dockerfile exists."""
    dockerfile_path = Path.cwd() / "tasks" / problem_id / "Dockerfile"
    return dockerfile_path.exists()


def build_docker_image(problem_id: str | None = None, force: bool = False):
    """Build the Docker image for the given problem or base image if no problem specified."""
    # Get the package's installed path
    package_path = Path(__file__).parent

    # Always ensure base image exists first
    if force or not check_docker_image_exists("apex_arena:base"):
        console.print("[yellow]Building apex_arena:base Docker image...[/yellow]")
        result = subprocess.run(
            [
                "docker",
                "build",
                "-t",
                "apex_arena:base",
                "-f",
                package_path / "Dockerfile",
                str(package_path),
            ],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            console.print(
                f"[red]Error building base Docker image: {result.stderr}[/red]"
            )
            sys.exit(1)
        console.print("[green]Base Docker image built successfully![/green]")

    # If no problem_id or no task-specific Dockerfile, return base image
    if not problem_id or not check_task_dockerfile(problem_id):
        return "apex_arena:base"

    # Check if task-specific image already exists
    image_name = f"apex_arena:{problem_id}"
    if not force and check_docker_image_exists(image_name):
        console.print(f"[green]Using existing task image {image_name}[/green]")
        return image_name

    # Build task-specific image if it doesn't exist or force is True
    task_dir = Path.cwd() / "tasks" / problem_id
    task_dockerfile = task_dir / "Dockerfile"
    console.print(
        f"[yellow]Building task-specific Docker image for {problem_id}...[/yellow]"
    )
    result = subprocess.run(
        [
            "docker",
            "build",
            "-t",
            image_name,
            "-f",
            str(task_dockerfile),
            ".",
        ],
        capture_output=True,
        text=True,
        cwd=task_dir,
    )
    if result.returncode != 0:
        console.print(f"[red]Error building task Docker image: {result.stderr}[/red]")
        sys.exit(1)
    console.print("[green]Specimen Docker image built successfully![/green]")
    return image_name


def run_mcp_server(problem_id: str | None = None, force: bool = False):
    """Run the MCP server."""
    console.print("[yellow]Starting MCP server...[/yellow]")

    # Ensure the restricted network exists
    create_restricted_network()

    # Build the appropriate Docker image
    image_name = build_docker_image(problem_id, force)

    # Generate container name based on problem_id or use default
    container_name = f"apex-arena-{problem_id}" if problem_id else "apex-arena-base"

    cmd = [
        "docker",
        "run",
        "--rm",  # Automatically remove container when it exits
        "--name",
        container_name,
        "-p",
        "8001:8001",
        "-v",
        f"{Path.cwd()}/tasks:/mcp_server/tasks",
        "-e",
        "MCP_TESTING_MODE=1",
        "-i",
        image_name,
        "python3",
        "/mcp_server/apex_arena/server.py",
    ]

    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,  # Line buffered
        universal_newlines=True,
    )

    # Wait a bit to ensure server starts
    import time

    time.sleep(2)

    if process.poll() is not None:
        stderr = process.stderr.read()
        console.print(f"[red]Error starting MCP server: {stderr}[/red]")
        sys.exit(1)

    console.print(
        f"[green]MCP server started successfully in container {container_name}![/green]"
    )

    # Start a thread to read and display stdout
    import threading

    def read_output(pipe, prefix):
        for line in pipe:
            console.print(f"{prefix} {line.strip()}")

    stdout_thread = threading.Thread(
        target=read_output, args=(process.stdout, "[blue]MCP[/blue]")
    )
    stderr_thread = threading.Thread(
        target=read_output, args=(process.stderr, "[red]MCP Error[/red]")
    )
    stdout_thread.daemon = True
    stderr_thread.daemon = True
    stdout_thread.start()
    stderr_thread.start()

    return process


def cleanup_container(container_name: str):
    """Clean up the Docker container."""
    try:
        subprocess.run(
            ["docker", "rm", "-f", container_name], capture_output=True, text=True
        )
        console.print(f"[green]Cleaned up container {container_name}[/green]")
    except Exception as e:
        console.print(
            f"[yellow]Warning: Could not clean up container {container_name}: {e}[/yellow]"
        )


def do_setup(problem_id: str | None = None, force: bool = False):
    """Perform the setup process."""
    # Generate container name based on problem_id or use default
    container_name = f"apex-arena-{problem_id}" if problem_id else "apex-arena-base"

    process = run_mcp_server(problem_id, force)

    try:
        console.print("[green]Setup complete! Press Ctrl+C to stop the server.[/green]")
        process.wait()
    except KeyboardInterrupt:
        console.print("\n[yellow]Shutting down MCP server...[/yellow]")
        process.terminate()
        process.wait()
    finally:
        cleanup_container(container_name)


def do_grade(problem_id: str, model: str, max_tokens: int = 8000):
    """Perform the grading process."""
    # Use the current Python executable instead of creating a separate venv
    # This ensures all dependencies are available
    python_path = sys.executable

    cmd = [
        str(python_path),
        "-m",
        "apex_arena.tester",
        "--problem_id",
        problem_id,
        "--model",
        model,
        "--max_tokens",
        str(max_tokens),
    ]

    console.print(f"[yellow]Running grader for problem: {problem_id}[/yellow]")

    # Run the process with live output
    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,  # Line buffered
        universal_newlines=True,
        env={
            **os.environ,
            "PYTHONUNBUFFERED": "1",
        },  # Ensure Python output is unbuffered
    )

    # Start threads to read and display output
    import threading

    def read_output(pipe, prefix):
        try:
            while True:
                line = pipe.readline()
                if not line and process.poll() is not None:
                    break
                if line:
                    console.print(f"{prefix} {line.strip()}")
                    console.file.flush()  # Force flush the output
        except Exception as e:
            console.print(f"[red]Error reading output: {escape(str(e))}[/red]")

    stdout_thread = threading.Thread(
        target=read_output, args=(process.stdout, "[green]Grader[/green]")
    )
    stderr_thread = threading.Thread(
        target=read_output, args=(process.stderr, "[red]Grader Error[/red]")
    )
    stdout_thread.daemon = True
    stderr_thread.daemon = True
    stdout_thread.start()
    stderr_thread.start()

    # Wait for the process to complete
    process.wait()

    # Wait for output threads to finish
    stdout_thread.join(timeout=1)
    stderr_thread.join(timeout=1)

    if process.returncode != 0:
        console.print("[red]Grading failed![/red]")
        sys.exit(1)

    console.print("[green]Grading completed![/green]")


async def do_tool_call(server_url: str, tool_name: str, tool_args: dict):
    """Perform a tool call on an existing MCP server."""
    try:
        from mcp import ClientSession
        from mcp.client.streamable_http import streamablehttp_client

        async with streamablehttp_client(server_url) as (
            read_stream,
            write_stream,
            _,
        ):
            async with ClientSession(read_stream, write_stream) as session:
                await session.initialize()

                # List available tools
                tools = await session.list_tools()
                available_tool_names = [tool.name for tool in tools.tools]

                if tool_name not in available_tool_names:
                    console.print(f"[red]Tool '{tool_name}' not found on server[/red]")
                    console.print(
                        f"[yellow]Available tools: {', '.join(available_tool_names)}[/yellow]"
                    )
                    return

                # Call the tool
                console.print(
                    f"[blue]Calling tool '{tool_name}' with args: {tool_args}[/blue]"
                )
                result = await session.call_tool(tool_name, tool_args)

                # Display result
                console.print("[green]Tool call successful![/green]")
                console.print("[bold]Result:[/bold]")

                for content in result.content:
                    if hasattr(content, "text"):
                        # Try to format as JSON if it looks like JSON
                        try:
                            parsed_json = json.loads(content.text)
                            syntax = Syntax(
                                json.dumps(parsed_json, indent=2),
                                "json",
                                theme="monokai",
                            )
                            console.print(syntax)
                        except (json.JSONDecodeError, TypeError):
                            # If not JSON, print as plain text
                            console.print(content.text)
                    else:
                        console.print(str(content))

                if result.isError:
                    console.print("[red]Tool call returned an error[/red]")

    except ImportError:
        console.print("[red]Error: Required MCP packages not available[/red]")
        console.print("[yellow]Make sure you have fastmcp installed[/yellow]")
    except Exception as e:
        console.print(f"[red]Error calling tool: {e}[/red]")


async def list_tools(server_url: str):
    """List all available tools on an MCP server."""
    try:
        from mcp import ClientSession
        from mcp.client.streamable_http import streamablehttp_client

        async with streamablehttp_client(server_url) as (
            read_stream,
            write_stream,
            _,
        ):
            async with ClientSession(read_stream, write_stream) as session:
                await session.initialize()

                # List available tools
                tools = await session.list_tools()

                if not tools.tools:
                    console.print("[yellow]No tools available on the server[/yellow]")
                    return

                # Create table to display tools
                table = Table(show_header=True, header_style="bold magenta")
                table.add_column("Tool Name", style="cyan")
                table.add_column("Description", style="white")
                table.add_column("Input Schema", style="dim")

                for tool in tools.tools:
                    # Format input schema
                    schema_str = ""
                    if hasattr(tool, "inputSchema") and tool.inputSchema:
                        if isinstance(tool.inputSchema, dict):
                            # Show properties if available
                            properties = tool.inputSchema.get("properties", {})
                            if properties:
                                schema_str = ", ".join(properties.keys())
                            else:
                                schema_str = str(tool.inputSchema.get("type", "object"))
                        else:
                            schema_str = str(tool.inputSchema)

                    table.add_row(
                        tool.name, tool.description or "No description", schema_str
                    )

                console.print(
                    f"\n[bold]Found {len(tools.tools)} tools on server:[/bold]"
                )
                console.print(table)

    except ImportError:
        console.print("[red]Error: Required MCP packages not available[/red]")
        console.print("[yellow]Make sure you have fastmcp installed[/yellow]")
    except Exception as e:
        console.print(f"[red]Error listing tools: {e}[/red]")


def interactive_task_selection(available_tasks: list) -> list:
    """Interactive checkbox selection of tasks."""

    # Start with all tasks selected by default
    selected = {task: False for task in available_tasks}

    while True:
        console.clear()
        console.print("[bold blue]Select tasks for Evaluation[/bold blue]\n")

        # Create a table showing tasks with checkboxes
        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("#", style="dim", width=3)
        table.add_column("Status", width=8)
        table.add_column("Specimen", style="cyan")

        for i, task in enumerate(available_tasks, 1):
            status = "[green]✓[/green]" if selected[task] else "[red]✗[/red]"
            table.add_row(str(i), status, task)

        console.print(table)

        selected_count = sum(selected.values())
        console.print(f"\n[dim]Selected: {selected_count}/{len(available_tasks)}[/dim]")

        console.print("\n[bold]Commands:[/bold]")
        console.print("• Enter number(s) to toggle (e.g., '1,3,5' or '2-4')")
        console.print("• 'all' or 'a' - select all tasks")
        console.print("• 'none' or 'n' - deselect all tasks")
        console.print("• 'done' or 'd' - confirm selection")
        console.print("• 'quit' or 'q' - cancel evaluation")

        choice = Prompt.ask("\nCommand", default="done").strip().lower()

        if choice in ("done", "d"):
            break
        elif choice in ("quit", "q"):
            return []
        elif choice in ("all", "a"):
            for task in available_tasks:
                selected[task] = True
        elif choice in ("none", "n"):
            for task in available_tasks:
                selected[task] = False
        else:
            # Parse number selections
            try:
                indices = parse_selection_indices(choice, len(available_tasks))
                for idx in indices:
                    task = available_tasks[idx - 1]  # Convert to 0-based
                    selected[task] = not selected[task]
            except ValueError as e:
                console.print(f"[red]Invalid selection: {e}[/red]")
                console.input("\nPress Enter to continue...")

    return [task for task in available_tasks if selected[task]]


def parse_selection_indices(choice: str, max_count: int) -> list:
    """Parse selection like '1,3,5' or '2-4' into list of indices."""
    indices = []

    for part in choice.split(","):
        part = part.strip()
        if "-" in part:
            # Handle range like '2-4'
            start, end = part.split("-", 1)
            start_idx = int(start.strip())
            end_idx = int(end.strip())
            if start_idx < 1 or end_idx > max_count or start_idx > end_idx:
                raise ValueError(f"Invalid range: {part}")
            indices.extend(range(start_idx, end_idx + 1))
        else:
            # Handle single number
            idx = int(part)
            if idx < 1 or idx > max_count:
                raise ValueError(f"Number out of range: {idx}")
            indices.append(idx)

    return indices


def do_eval_interactive(force_build: bool = False):
    """Interactive evaluation setup."""
    import os

    # Discover available tasks
    tasks_dir = Path.cwd() / "tasks"
    from .eval_runner import EvalRunner

    runner = EvalRunner()
    available_tasks = runner.discover_tasks(tasks_dir)

    if not available_tasks:
        console.print("[red]No valid tasks found in tasks/ directory[/red]")
        return

    # Interactive task selection with checkboxes
    selected_tasks = interactive_task_selection(available_tasks)

    if not selected_tasks:
        console.print("[yellow]No tasks selected. Cancelling evaluation.[/yellow]")
        return

    # Get number of runs
    runs = int(Prompt.ask("Number of runs per task", default="3"))

    # Get other options
    model = Prompt.ask("Model to use", default="biggie")
    max_tokens = int(Prompt.ask("Max tokens", default="4096"))
    max_turns = int(Prompt.ask("Max conversation turns", default="100"))
    concurrency = int(Prompt.ask("Max concurrency", default="3"))
    debug_mode = Confirm.ask(
        "Enable debug mode (disables live progress bar)?", default=False
    )

    # Get streaming options (default to enabled)
    stream_results = Confirm.ask("Stream results to server?", default=True)
    apex_server_url = None
    apex_api_key = None

    if stream_results:
        apex_server_url = Prompt.ask(
            "Server URL",
            default=os.getenv(
                "APEX_SERVER_URL", "https://apex-ui-319533213591.us-central1.run.app/"
            ),
        )
        apex_api_key = os.getenv("APEX_API_KEY")

        if not apex_api_key:
            console.print(
                "[red]Error: APEX_API_KEY environment variable must be set for streaming.[/red]"
            )
            console.print("[red]Please set APEX_API_KEY and try again.[/red]")
            return

    # Get output file
    output_file = Prompt.ask("Output JSON file", default="eval_results.json")

    # Confirm before running
    total_evals = len(selected_tasks) * runs
    console.print("\n[bold]Evaluation Summary:[/bold]")
    console.print(f"tasks: {', '.join(selected_tasks)}")
    console.print(f"Runs per task: {runs}")
    console.print(f"Total evaluations: {total_evals}")
    console.print(f"Max concurrency: {concurrency}")
    console.print(f"Output file: {output_file}")

    if not Confirm.ask("Proceed with evaluation?"):
        console.print("[yellow]Evaluation cancelled[/yellow]")
        return

    # Run the evaluation
    asyncio.run(
        do_eval(
            selected_tasks,
            runs,
            model,
            max_tokens,
            max_turns,
            concurrency,
            output_file,
            debug_mode,
            stream_results,
            apex_server_url,
            apex_api_key,
            force_build=force_build,
        )
    )


async def do_eval(
    tasks: list,
    runs: int,
    model: str,
    max_tokens: int,
    max_turns: int,
    concurrency: int,
    output_file: str,
    debug_mode: bool = False,
    stream_results: bool = False,
    apex_server_url: Optional[str] = None,
    apex_api_key: Optional[str] = None,
    force_build: bool = False,
):
    """Run the evaluation."""
    from .eval_runner import eval_runner_context

    try:
        async with eval_runner_context(
            model=model,
            max_tokens=max_tokens,
            max_turns=max_turns,
            max_concurrency=concurrency,
            debug_mode=debug_mode,
            stream_results=stream_results,
            apex_server_url=apex_server_url,
            apex_api_key=apex_api_key,
        ) as runner:
            results = await runner.run_evaluation(tasks, runs, force_build=force_build)

            # Write results to file
            with open(output_file, "w") as f:
                json.dump(results, f, indent=2)

            console.print(
                f"\n[green]Evaluation completed! Results saved to {output_file}[/green]"
            )

            # Print summary
            console.print("\n[bold]Summary:[/bold]")
            for task, agg in results["aggregated_results"].items():
                console.print(
                    f"[blue]{task}:[/blue] Mean score: {agg['mean_score']:.3f} ± {agg['std_dev']:.3f}, Success rate: {agg['success_rate']:.1%}"
                )

            console.print("\n[dim]Transcripts saved to: eval_transcripts/[/dim]")

    except Exception as e:
        console.print(f"[red]Evaluation failed: {e}[/red]")
        raise


def interactive_menu():
    """Run the interactive menu."""
    console.print(Panel.fit(APEX_ASCII_ART, style="bold blue"))
    console.print(Panel(WELCOME_MESSAGE, style="bold white"))

    while True:
        choice = Prompt.ask(
            "What would you like to do?", choices=["1", "2", "3", "exit"], default="1"
        )

        if choice == "exit":
            console.print("[yellow]Goodbye! 👋[/yellow]")
            break
        elif choice == "1":
            problem_id = Prompt.ask(
                "Enter the problem ID (optional, press Enter to skip)", default=""
            )
            do_setup(problem_id if problem_id else None)
        elif choice == "2":
            problem_id = Prompt.ask("Enter the problem ID")
            model = Prompt.ask("Enter the model name", default="biggie")
            max_tokens = Prompt.ask("Enter the max tokens", default=8000)
            do_grade(problem_id, model, max_tokens)
        elif choice == "3":
            # TODO: Add force build option
            do_eval_interactive(force_build=False)


@click.group()
def cli():
    """Apex Arena CLI tool for testing and grading problems."""
    pass


@cli.command()
def start():
    """Start the Apex Arena interactive interface."""
    interactive_menu()


@cli.command()
@click.argument("problem_id", required=False)
@click.option("--force", is_flag=True, help="Force rebuild the Docker image")
def setup(problem_id: str | None = None, force: bool = False):
    """Setup the Apex Arena environment."""
    do_setup(problem_id, force)


@cli.command()
@click.argument("problem_id")
@click.option("--model", default="biggie", help="Model to use for testing")
@click.option("--max_tokens", default=8000, help="Max tokens to use for testing")
def grade(problem_id: str, model: str, max_tokens: int):
    """Grade a specific problem."""
    do_grade(problem_id, model, max_tokens)


@cli.command()
@click.option(
    "--tasks",
    help="Comma-separated list of tasks to evaluate, or 'all' for all tasks",
)
@click.option("--runs", default=3, help="Number of runs per task")
@click.option("--model", default="biggie", help="Model to use for evaluation")
@click.option("--max_tokens", default=8000, help="Max tokens per evaluation")
@click.option("--max_turns", default=200, help="Max conversation turns per evaluation")
@click.option("--concurrency", default=3, help="Maximum concurrent evaluations")
@click.option("--output", default="eval_results.json", help="Output JSON file")
@click.option(
    "--debug", is_flag=True, help="Enable debug mode (disables live progress bar)"
)
@click.option(
    "--no-stream",
    is_flag=True,
    help="Disable streaming results to server (streaming is enabled by default)",
)
@click.option(
    "--server-url",
    help="Apex UI server URL (defaults to APEX_SERVER_URL env var or https://apex-ui-319533213591.us-central1.run.app/)",
)
@click.option(
    "--api-key",
    help="Worker API key for authentication (defaults to APEX_API_KEY env var)",
)
@click.option(
    "--force-build",
    is_flag=True,
    help="Force rebuild the Docker image",
)
def eval(
    tasks: str,
    runs: int,
    model: str,
    max_tokens: int,
    max_turns: int,
    concurrency: int,
    output: str,
    debug: bool,
    no_stream: bool,
    apex_server_url: str,
    apex_api_key: str,
    force_build: bool = False,
):
    """Run evaluations across multiple tasks and aggregate results."""
    breakpoint()
    from .eval_runner import EvalRunner

    # Configure streaming
    stream_results = not no_stream
    if stream_results:
        # Get server URL and API key from args or environment
        if not apex_server_url:
            apex_server_url = os.getenv(
                "APEX_SERVER_URL", "https://apex-ui-319533213591.us-central1.run.app/"
            )
        if not apex_api_key:
            apex_api_key = os.getenv("APEX_API_KEY")

        if not apex_api_key:
            console.print(
                "[yellow]Warning: No API key provided. Use --api-key or set APEX_API_KEY environment variable.[/yellow]"
            )
            console.print("[yellow]Disabling streaming...[/yellow]")
            stream_results = False

    # Discover available tasks
    runner = EvalRunner()
    available_tasks = runner.discover_tasks()

    if not available_tasks:
        console.print("[red]No valid tasks found in tasks/ directory[/red]")
        return

    # Parse task selection
    if not tasks:
        tasks = "all"

    if tasks.lower() == "all":
        selected_tasks = available_tasks
    else:
        selected_tasks = [s.strip() for s in tasks.split(",")]
        # Validate selections
        invalid = [s for s in selected_tasks if s not in available_tasks]
        if invalid:
            console.print(f"[red]Invalid tasks: {', '.join(invalid)}[/red]")
            console.print(f"[blue]Available tasks:[/blue] {', '.join(available_tasks)}")
            return

    console.print(
        f"[green]Running evaluation on {len(selected_tasks)} tasks with {runs} runs each[/green]"
    )

    # Run the evaluation
    asyncio.run(
        do_eval(
            selected_tasks,
            runs,
            model,
            max_tokens,
            max_turns,
            concurrency,
            output,
            debug,
            stream_results,
            apex_server_url,
            apex_api_key,
            force_build=force_build,
        )
    )


@cli.group()
def tasks():
    """Manage tasks in Apex Arena."""
    pass


@cli.group()
def evaluations():
    """Run and manage evaluations."""
    pass


@evaluations.command("run")
@click.argument("task_ids", required=False)
@click.option(
    "--task-file",
    type=click.Path(exists=True, path_type=Path),
    help="Path to file containing task IDs (one per line)",
)
@click.option("--runs", default=3, help="Number of runs per task")
@click.option("--model", default="biggie", help="Model to use for evaluation")
@click.option("--max_tokens", default=4096, help="Max tokens per evaluation")
@click.option("--max_turns", default=100, help="Max conversation turns per evaluation")
@click.option("--concurrency", default=3, help="Maximum concurrent evaluations")
@click.option("--output", default="eval_results.json", help="Output JSON file")
@click.option(
    "--debug", is_flag=True, help="Enable debug mode (disables live progress bar)"
)
@click.option(
    "--no-stream",
    is_flag=True,
    help="Disable streaming results to server (streaming is enabled by default)",
)
@click.option(
    "--server-url",
    help="Apex UI server URL (defaults to APEX_SERVER_URL env var or https://apex-ui-319533213591.us-central1.run.app/)",
)
@click.option(
    "--api-key",
    help="Worker API key for authentication (defaults to APEX_API_KEY env var)",
)
@click.option(
    "--force-build",
    is_flag=True,
    help="Force rebuild the Docker image",
)
def run_evaluation(
    task_ids: str,
    task_file: Path,
    runs: int,
    model: str,
    max_tokens: int,
    max_turns: int,
    concurrency: int,
    output: str,
    debug: bool,
    no_stream: bool,
    server_url: str,
    api_key: str,
    force_build: bool = False,
):
    """Run evaluations on specified local tasks or remote tasks."""
    try:
        from .task_resolver import get_tasks_dir, parse_task_ids, resolve_tasks

        # Handle task IDs from file or command line argument
        if task_file and task_ids:
            console.print(
                "[red]Error: Cannot specify both task_ids and --task-file.[/red]"
            )
            sys.exit(1)

        if task_file:
            # Read task IDs from file
            try:
                with open(task_file, "r") as f:
                    task_id_list = [line.strip() for line in f if line.strip()]
                console.print(
                    f"[blue]Loaded {len(task_id_list)} task IDs from {task_file}[/blue]"
                )
            except Exception as e:
                console.print(f"[red]Error reading task file: {e}[/red]")
                sys.exit(1)
        elif task_ids:
            # Parse task IDs from command line
            task_id_list = parse_task_ids(task_ids)
        else:
            console.print(
                "[red]Error: Must specify either task IDs or --task-file.[/red]"
            )
            console.print(
                "[yellow]Usage: apex-arena evaluations run task1,task2,task3[/yellow]"
            )
            console.print(
                "[yellow]   or: apex-arena evaluations run --task-file target_tasks.txt[/yellow]"
            )
            sys.exit(1)

        if not task_id_list:
            console.print("[red]Error: No task IDs found.[/red]")
            sys.exit(1)

        tasks_dir = get_tasks_dir()
        console.print(f"[blue]Using tasks directory: {tasks_dir}[/blue]")
        console.print(f"[blue]Resolving {len(task_id_list)} task(s)...[/blue]")

        # Resolve task IDs to local tasks (download remote tasks if needed)
        resolved_tasks = resolve_tasks(task_id_list)

        console.print(
            f"[green]✓ Resolved {len(resolved_tasks)} task(s): {', '.join(resolved_tasks)}[/green]"
        )

        # Configure streaming (same logic as existing eval command)
        stream_results = not no_stream
        if stream_results:
            # Get server URL and API key from args or environment
            if not server_url:
                server_url = os.getenv(
                    "APEX_SERVER_URL",
                    "https://apex-ui-319533213591.us-central1.run.app/",
                )
            if not api_key:
                api_key = os.getenv("APEX_API_KEY")

            if not api_key:
                console.print(
                    "[yellow]Warning: No API key provided. Use --api-key or set APEX_API_KEY environment variable.[/yellow]"
                )
                console.print("[yellow]Disabling streaming...[/yellow]")
                stream_results = False

        # Run the evaluation using existing infrastructure
        console.print(
            f"[green]Running evaluation on {len(resolved_tasks)} tasks with {runs} runs each[/green]"
        )

        # Use the existing do_eval function with resolved tasks
        asyncio.run(
            do_eval(
                resolved_tasks,
                runs,
                model,
                max_tokens,
                max_turns,
                concurrency,
                output,
                debug,
                stream_results,
                server_url,
                api_key,
                force_build=force_build,
            )
        )

    except ImportError:
        console.print(
            "[red]Error: requests library is required. Install with: pip install requests[/red]"
        )
        sys.exit(1)
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Error running evaluation: {e}[/red]")
        sys.exit(1)


@tasks.command("list")
def list_tasks():
    """List all tasks for authenticated user."""
    try:
        from .api_client import get_api_client

        api_client = get_api_client()

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description="Fetching tasks...", total=None)
            tasks_data = api_client.list_tasks()

        if not tasks_data:
            console.print("[yellow]No tasks found.[/yellow]")
            return

        # Create table to display tasks
        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("ID", style="dim", width=8)
        table.add_column("Name", style="cyan")
        table.add_column("Status", width=10)

        # Check if admin fields are present (only for admin users)
        has_admin_fields = tasks_data and (
            "pushed_to_taiga" in tasks_data[0]
            or "passed_quality_check" in tasks_data[0]
        )
        if has_admin_fields:
            table.add_column("Quality Check", width=12)
            table.add_column("Pushed to Taiga", width=14)

        table.add_column("Created", style="dim")
        table.add_column("Creator", style="dim")

        for task in tasks_data:
            # Truncate ID for display
            task_id = (
                task.get("id", "")[:8] + "..."
                if len(task.get("id", "")) > 8
                else task.get("id", "")
            )

            # Format status with colors
            status = task.get("status", "N/A")
            if status == "active":
                status = f"[green]{status}[/green]"
            elif status == "inactive":
                status = f"[red]{status}[/red]"

            # Format date
            date_created = task.get("date_created", "")
            if date_created:
                # Extract just the date part
                date_created = (
                    date_created.split("T")[0] if "T" in date_created else date_created
                )

            # Build row data
            row_data = [
                task_id,
                task.get("name", "N/A"),
                status,
            ]

            # Add admin fields if present
            if has_admin_fields:
                quality_check = (
                    "[green]✓[/green]"
                    if task.get("passed_quality_check")
                    else "[red]✗[/red]"
                )
                pushed_to_taiga = (
                    "[green]✓[/green]"
                    if task.get("pushed_to_taiga")
                    else "[red]✗[/red]"
                )
                row_data.extend([quality_check, pushed_to_taiga])

            # Add common fields
            row_data.extend([date_created, task.get("creator_email", "N/A")])

            table.add_row(*row_data)

        console.print(f"\n[bold]Found {len(tasks_data)} tasks:[/bold]")
        console.print(table)

    except ImportError:
        console.print(
            "[red]Error: requests library is required. Install with: pip install requests[/red]"
        )
        sys.exit(1)
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
        console.print("[yellow]Please set APEX_API_KEY environment variable.[/yellow]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Error fetching tasks: {e}[/red]")
        sys.exit(1)


@tasks.command("push")
@click.argument(
    "directory", type=click.Path(exists=True, file_okay=False, path_type=Path)
)
@click.option("--name", help="Task name (defaults to directory name)")
def push_task(directory: Path, name: str):
    """Push a task directory to GCS."""
    try:
        from .api_client import get_api_client

        # Use provided name or default to directory name
        if not name:
            default_name = directory.name
            console.print(f"[dim]Directory: {directory}[/dim]")
            name = Prompt.ask("Enter task name", default=default_name)
        else:
            console.print(f"[dim]Directory: {directory}[/dim]")
            console.print(f"[dim]Task name: {name}[/dim]")

        if not name or not name.strip():
            console.print("[red]Task name cannot be empty.[/red]")
            sys.exit(1)

        name = name.strip()

        api_client = get_api_client()

        console.print(
            f"[yellow]Uploading task '{name}' from directory: {directory}[/yellow]"
        )

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description="Uploading files...", total=None)
            result = api_client.upload_task(directory, name)

        console.print("[green]✓ Task uploaded successfully![/green]")
        console.print(f"[dim]Task ID: {result['id']}[/dim]")
        console.print(f"[dim]Created: {result['date_created']}[/dim]")

    except ImportError:
        console.print(
            "[red]Error: requests library is required. Install with: pip install requests[/red]"
        )
        sys.exit(1)
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
        if "APEX_API_KEY" in str(e):
            console.print(
                "[yellow]Please set APEX_API_KEY environment variable.[/yellow]"
            )
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Error uploading task: {e}[/red]")
        sys.exit(1)


@cli.group()
def tools():
    """Interact with MCP server tools."""
    pass


@tools.command("list")
@click.option(
    "--server-url",
    default="http://localhost:8001/mcp/",
    help="MCP server URL",
)
def list_server_tools(server_url: str):
    """List all available tools on an MCP server."""
    console.print(f"[blue]Connecting to MCP server at: {server_url}[/blue]")
    asyncio.run(list_tools(server_url))


@tools.command("call")
@click.argument("tool_name")
@click.option(
    "--server-url",
    default="http://localhost:8001/mcp/",
    help="MCP server URL",
)
@click.option(
    "--args",
    help='JSON string of tool arguments (e.g. \'{"key": "value"}\')',
)
def call_tool_cmd(tool_name: str, server_url: str, args: str):
    """Call a specific tool on an MCP server."""
    console.print(f"[blue]Connecting to MCP server at: {server_url}[/blue]")

    # Parse arguments
    tool_args = {}
    if args:
        try:
            tool_args = json.loads(args)
        except json.JSONDecodeError as e:
            console.print(f"[red]Invalid JSON in args: {e}[/red]")
            console.print('[yellow]Example: --args \'{"problem_id": "test"}\'[/yellow]')
            sys.exit(1)

    asyncio.run(do_tool_call(server_url, tool_name, tool_args))


if __name__ == "__main__":
    cli()
