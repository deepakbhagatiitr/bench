import os
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import urljoin

try:
    import requests
except ImportError:
    requests = None


class ApexAPIClient:
    """Client for interacting with Apex UI backend API."""

    def __init__(self, server_url: Optional[str] = None, api_key: Optional[str] = None):
        self.server_url = server_url or os.getenv(
            "APEX_SERVER_URL", "https://apex-ui-319533213591.us-central1.run.app/"
        )
        self.api_key = api_key or os.getenv("APEX_API_KEY")

        if not self.server_url.endswith("/"):
            self.server_url += "/"

        if requests is None:
            raise ImportError(
                "requests library is required for API client. "
                "Install with: pip install requests"
            )

    def _get_headers(self) -> Dict[str, str]:
        """Get HTTP headers for API requests."""
        headers = {
            "Accept": "application/json",
        }

        if self.api_key:
            headers["x-api-key"] = self.api_key

        return headers

    def _make_request(self, method: str, endpoint: str, **kwargs) -> requests.Response:
        """Make HTTP request to API."""
        url = urljoin(self.server_url, endpoint)
        headers = self._get_headers()

        if "headers" in kwargs:
            headers.update(kwargs["headers"])
            del kwargs["headers"]

        response = requests.request(method, url, headers=headers, **kwargs)
        response.raise_for_status()
        return response

    def list_tasks(self) -> List[Dict]:
        """List all tasks for authenticated user."""
        if not self.api_key:
            raise ValueError("APEX_API_KEY is required for authentication")

        response = self._make_request("GET", "api/tasks")
        return response.json()

    def upload_task(self, directory: Path, name: str) -> Dict:
        """Upload a task directory to GCS."""
        if not self.api_key:
            raise ValueError("APEX_API_KEY is required for authentication")

        if not directory.exists() or not directory.is_dir():
            raise ValueError(f"Directory does not exist: {directory}")

        # Collect all files in directory recursively
        files_to_upload = []

        for file_path in directory.rglob("*"):
            if file_path.is_file():
                # Calculate relative path from directory root
                relative_path = file_path.relative_to(directory)
                relative_path_str = str(relative_path)

                # Read file content
                with open(file_path, "rb") as f:
                    file_content = f.read()

                # Use relative path as filename
                files_to_upload.append(("files", (relative_path_str, file_content)))

        if not files_to_upload:
            raise ValueError(f"No files found in directory: {directory}")

        # Prepare form data - separate regular data from files
        data = {"name": name}

        response = self._make_request(
            "POST", "api/tasks", data=data, files=files_to_upload
        )
        return response.json()

    def get_task(self, task_id: str) -> Dict:
        """Get task information by ID."""
        if not self.api_key:
            raise ValueError("APEX_API_KEY is required for authentication")

        response = self._make_request("GET", f"api/tasks/{task_id}")
        return response.json()

    def download_task(self, task_id: str) -> bytes:
        """Download task files and create ZIP archive locally."""
        if not self.api_key:
            raise ValueError("APEX_API_KEY is required for authentication")

        # Get signed URLs from the API
        response = self._make_request("GET", f"api/tasks/{task_id}/download")
        download_info = response.json()

        if "files" not in download_info:
            raise ValueError("Invalid response format from download API")

        files = download_info["files"]
        if not files:
            raise ValueError(f"No files found for task {task_id}")

        # Create ZIP archive in memory
        import io
        import zipfile

        zip_buffer = io.BytesIO()

        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
            for file_info in files:
                file_path = file_info["path"]
                signed_url = file_info["url"]

                try:
                    # Download file content using signed URL
                    file_response = requests.get(signed_url)
                    file_response.raise_for_status()

                    # Add to ZIP archive
                    zip_file.writestr(file_path, file_response.content)

                except Exception as e:
                    print(f"Warning: Failed to download {file_path}: {e}")
                    continue

        zip_buffer.seek(0)
        return zip_buffer.getvalue()


def get_api_client() -> ApexAPIClient:
    """Get configured API client instance."""
    return ApexAPIClient()
