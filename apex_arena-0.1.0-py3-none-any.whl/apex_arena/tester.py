import asyncio
import os
from typing import Any, Dict, List, Optional

import aiohttp
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

from .utils import (
    mcp_content_block_to_messages_format,
    messages_to_raw_prompt,
)

MAX_ALLOWED_TOOL_CALLS = 100

API_URL = os.environ.get("API_URL", "https://proxy-319533213591.us-west2.run.app")


class ProxyError(Exception):
    """Exception raised by ProxyClient that preserves HTTP status code."""

    def __init__(self, message: str, status_code: int):
        super().__init__(message)
        self.status_code = status_code


class ProxyClient:
    def __init__(self, url: str = f"{API_URL}/v1/messages"):
        self.url = url
        self.api_key = os.getenv("APEX_API_KEY", None)
        assert self.api_key is not None, "APEX_API_KEY is not set"
        connector = aiohttp.TCPConnector(limit=10000)
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=240),
            connector=connector,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
        )

    async def create_message(
        self,
        model: str,
        messages: List[Dict],
        max_tokens: int,
        tools: Optional[List[Dict]] = None,
    ) -> Dict[str, Any]:
        payload = {
            "model": model,
            "max_tokens": max_tokens,
            "messages": messages,
            "temperature": 0.7,
            "thinking_tokens": 2048,
            "available_tools": tools,
        }

        async with self.session.post(self.url, json=payload) as response:
            if response.status != 200:
                error_text = await response.text()
                raise ProxyError(f"Proxy error: {error_text}", response.status)

            return await response.json()

    def __del__(self):
        asyncio.create_task(self.session.close())


class ApexArenaClient:
    def __init__(
        self,
        server_url: str = "http://localhost:8001/mcp/",
        model: str = "biggie",
        max_tokens: int = 1000,
    ):
        self.server_url = server_url
        self.model = model
        self.max_tokens = max_tokens
        self.proxy = ProxyClient()

    async def run_problem(self, problem_id: str) -> Dict[str, Any]:
        async with streamablehttp_client(
            self.server_url,
            timeout=600.0,
            sse_read_timeout=800.0,
        ) as (
            read_stream,
            write_stream,
            _,
        ):
            async with ClientSession(read_stream, write_stream) as session:
                await session.initialize()

                setup_result = await session.call_tool(
                    "setup_problem", {"problem_id": problem_id}
                )

                tools = await session.list_tools()
                available_tools = [
                    {
                        "name": tool.name,
                        "description": tool.description,
                        "input_schema": tool.inputSchema,
                    }
                    for tool in tools.tools
                    if tool.name != "setup_problem"
                ]
                num_tool_calls = 0

                prompt = setup_result.content[0].text
                messages = [{"role": "user", "content": prompt}]

                while True:
                    for message in messages[:-2]:
                        if message["role"] == "assistant":
                            for content in message["content"]:
                                if (
                                    isinstance(content, dict)
                                    and content.get("type") == "tool_use"
                                ):
                                    if "cache_control" in content:
                                        content["cache_control"] = None

                    # Retry logic for rate limiting
                    max_retries = 10
                    for attempt in range(max_retries + 1):
                        try:
                            response = await self.proxy.create_message(
                                model=self.model,
                                messages=messages,
                                max_tokens=self.max_tokens,
                                tools=available_tools,
                            )
                            break  # Success, exit retry loop
                        except Exception as e:
                            if attempt < max_retries and 'budget' not in str(e).lower() and 'invalid api' not in str(e).lower():
                                # Exponential backoff: 2^attempt seconds
                                delay = min(2**attempt, 30)
                                await asyncio.sleep(delay)
                                print(f"Retrying ({attempt}/{max_retries}). error: {e}")
                                continue
                            else:
                                print(f"Errored out after {max_retries} retries. error: {e}")
                                return {
                                    "problem_id": problem_id,
                                    "grade_result": {
                                        "subscores": {"initial": 0.0},
                                        "weights": {"initial": 1.0},
                                    },
                                }

                    if response["stop_reason"] == "refusal":
                        print("Model refused to answer")
                        return {
                            "problem_id": problem_id,
                            "grade_result": {
                                "subscores": {"initial": 0.0},
                                "weights": {"initial": 1.0},
                            },
                        }
                    if response["stop_reason"] in ["max_tokens", "end_turn"]:
                        grade = await session.call_tool(
                            "grade_problem",
                            {
                                "transcript": messages_to_raw_prompt(
                                    "[system_prompt_placeholder]\n\n", messages
                                ),
                                "problem_id": problem_id,
                            },
                        )
                        return {
                            "problem_id": problem_id,
                            "grade_result": grade.content[0].text,
                        }

                    if not response.get("content"):
                        return {
                            "problem_id": problem_id,
                            "grade_result": {
                                "subscores": {"initial": 0.0},
                                "weights": {"initial": 1.0},
                                "metadata": {
                                    "feedback": "Agent might have not called grade_problem tool call!"
                                },
                            },
                        }

                    assistant_content = []
                    tool_results = []
                    has_tool_call = False
                    tool_call_idx = []

                    for idx, content in enumerate(response["content"]):
                        if content["type"] == "tool_use":
                            tool_call_idx.append(idx)

                    for idx, content in enumerate(response["content"]):
                        if content["type"] == "tool_use":
                            has_tool_call = True
                            tool_name = content["name"]
                            tool_args = content["input"]
                            tool_id = content["id"]
                            print(f"Tool name: {tool_name}")
                            print(f"Tool args: {tool_args}")

                            if tool_name == "grade_problem":
                                tool_result = await session.call_tool(
                                    tool_name, tool_args
                                )
                                return {
                                    "problem_id": problem_id,
                                    "grade_result": tool_result.content[0].text,
                                }

                            tool_result = await session.call_tool(tool_name, tool_args)
                            num_tool_calls += 1
                            print(f"Tool result: {tool_result.content[0].text}")

                            if "text" in content and content["text"]:
                                assistant_content.append(
                                    {"type": "text", "text": content["text"]}
                                )
                            assistant_content.append(
                                {
                                    "type": "tool_use",
                                    "id": content["id"],
                                    "name": content["name"],
                                    "input": content["input"],
                                    "cache_control": {"type": "ephemeral"}
                                    if idx == tool_call_idx[-1]
                                    else None,
                                }
                            )
                            tool_results.append(
                                {
                                    "type": "tool_result",
                                    "is_error": tool_result.isError,
                                    "tool_use_id": tool_id,
                                    "content": [
                                        mcp_content_block_to_messages_format(content)
                                        for content in tool_result.content
                                    ],
                                }
                            )
                        elif content["type"] == "text":
                            print(f"Text: {content['text']}")

                            if (
                                "<answer>" in content["text"]
                                and "</answer>" in content["text"]
                            ):
                                grade = await session.call_tool(
                                    "grade_problem",
                                    {
                                        "transcript": messages_to_raw_prompt(
                                            "[system_prompt_placeholder]\n\n", messages
                                        ),
                                        "problem_id": problem_id,
                                    },
                                )
                                return {
                                    "problem_id": problem_id,
                                    "grade_result": grade.content[0].text,
                                }

                            assistant_content.append(
                                {"type": "text", "text": content["text"]}
                            )
                        elif content["type"] == "thinking":
                            assistant_content.append(content)

                    messages.append({"role": "assistant", "content": assistant_content})
                    if num_tool_calls > MAX_ALLOWED_TOOL_CALLS:
                        print(f"Tool calls exceeded {MAX_ALLOWED_TOOL_CALLS}")
                        grade = await session.call_tool(
                            "grade_problem",
                            {
                                "transcript": messages_to_raw_prompt(
                                    "[system_prompt_placeholder]\n\n", messages
                                ),
                                "problem_id": problem_id,
                            },
                        )
                        return {
                            "problem_id": problem_id,
                            "grade_result": grade.content[0].text,
                        }

                    if not has_tool_call:
                        grade = await session.call_tool(
                            "grade_problem",
                            {
                                "transcript": messages_to_raw_prompt(
                                    "[system_prompt_placeholder]\n\n", messages
                                ),
                                "problem_id": problem_id,
                            },
                        )
                        return {
                            "problem_id": problem_id,
                            "grade_result": grade.content[0].text,
                        }
                    else:
                        messages.append(
                            {
                                "role": "user",
                                "content": tool_results,
                            }
                        )


async def main():
    import argparse

    parser = argparse.ArgumentParser(description="Run problems through Apex Arena")
    parser.add_argument(
        "--problem_id", default="git_wizardry", help="Problem ID to run"
    )
    parser.add_argument(
        "--server", default="http://localhost:8001/mcp/", help="MCP server URL"
    )
    parser.add_argument(
        "--model", default="biggie", help="Model to use (biggie or smallie)"
    )
    parser.add_argument("--max_tokens", default=1000, help="Max tokens to use")
    args = parser.parse_args()

    client = ApexArenaClient(args.server, args.model, int(args.max_tokens))
    result = await client.run_problem(args.problem_id)

    print(f"\nProblem: {result['problem_id']}")
    print("\nGrade Result:")
    print(result)


if __name__ == "__main__":
    asyncio.run(main())
