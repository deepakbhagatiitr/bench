import importlib.util
import os
import re
import sys
from pathlib import Path

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from apex_arena.prompts import get_problem_metadata, load_problem_prompt
from apex_arena.utils import Grade

BASE_DIR = os.environ.get("BASE_DIR", "/mcp_server")

mcp = FastMCP("apex-arena", host="0.0.0.0", port=8001)
TEST_MODE = os.environ.get("MCP_TESTING_MODE", "0") in ["1", "true"]

if TEST_MODE:
    from apex_arena.tools import BashTool, Command, EditTool

    bash_tool = BashTool()

    @mcp.tool()
    async def bash(command: str, restart: bool = False):
        return await bash_tool(command, restart)

    edit_tool = EditTool()

    @mcp.tool(
        name="str_replace_editor",
        description="Create and edit files using str_replace_editor. Please do not use this tool to delete or clear files and use bash instead. Please use absolute paths for all file names.  When writing files please work within /workdir.",
    )
    async def str_replace_editor(
        *,
        command: Command,
        path: str,
        file_text: str | None = None,
        view_range: list[int] | None = None,
        old_str: str | None = None,
        new_str: str | None = None,
        insert_line: int | None = None,
    ):
        return await edit_tool(
            command=command,
            path=path,
            file_text=file_text,
            view_range=view_range,
            old_str=old_str,
            new_str=new_str,
            insert_line=insert_line,
        )


current_problem = None
current_grader = None
last_grader = Grade(
    subscores={"initial": 0.0},
    weights={"initial": 1.0},
    metadata={"feedback": "Agent call failed!"},
)


@mcp.tool()
async def setup_problem(
    problem_id: str = Field(description="The ID of the problem to set up"),
) -> str:
    global current_problem, current_grader

    prompt = load_problem_prompt(problem_id)
    metadata = get_problem_metadata(problem_id)

    grader_path = Path(BASE_DIR) / "tasks" / problem_id / "grader.py"
    if not grader_path.exists():
        raise ValueError(f"Grader not found for problem {problem_id}")

    spec = importlib.util.spec_from_file_location("grader", grader_path)
    grader_module = importlib.util.module_from_spec(spec)
    sys.modules["grader"] = grader_module
    spec.loader.exec_module(grader_module)

    setup_script = Path(BASE_DIR) / "tasks" / problem_id / "setup.sh"
    if setup_script.exists():
        import subprocess

        subprocess.run(["bash", str(setup_script)], check=True)

    current_problem = problem_id
    current_grader = grader_module

    return prompt


@mcp.tool()
async def grade_problem(
    problem_id: str,
    transcript: str = Field(
        description="The entire transcript produced by the model and its tool calls"
    ),
) -> Grade:
    global current_problem, current_grader

    if not current_problem or not current_grader:
        raise ValueError("No problem is currently set up")

    try:
        matches = re.findall(r"<answer>(.*?)</answer>", transcript, re.DOTALL)
        if matches:
            solution = matches[-1]
        else:
            solution = transcript
    except Exception as e:
        return Grade(
            subscores={"solution_found": 0.0},
            weights={"solution_found": 1.0},
            metadata={
                "feedback": f"Error extracting solution from answer tags: {str(e)}"
            },
        )

    result = current_grader.grade(solution)
    return Grade(
        subscores=result.subscores,
        weights=result.weights,
        metadata={"feedback": result.feedback},
    )


def main():
    os.chdir("/workdir")
    if TEST_MODE:
        mcp.run(transport="streamable-http")
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
