import asyncio
import concurrent
import contextlib
import datetime
import json
import logging
import os
import socket
import statistics
import subprocess
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass
from datetime import timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

import httpx
from rich.console import Console
from rich.live import Live
from rich.markup import escape
from rich.progress import Progress
from tqdm import tqdm

from .cli import build_docker_image
from .result_streamer import ResultStreamer, extract_score_from_grade_result
from .tester import ApexArenaClient, ProxyClient

logger = logging.getLogger(__name__)
console = Console()


class LoggingApexArenaClient(ApexArenaClient):
    def __init__(
        self,
        server_url: str,
        model: str,
        max_tokens: int,
        run_id: str,
        transcript_file: Path,
        max_turns: int = 50,
        # New streaming parameters
        streamer: Optional[ResultStreamer] = None,
        evaluation_id: Optional[str] = None,
        rollout_id: Optional[str] = None,
    ):
        super().__init__(server_url, model, max_tokens)
        self.proxy = ProxyClient()
        self.run_id = run_id
        self.transcript_file = transcript_file
        self.transcript_log = []
        self.max_turns = max_turns

        # Streaming configuration
        self.streamer = streamer
        self.evaluation_id = evaluation_id
        self.rollout_id = rollout_id
        self.conversation_sequence = 0  # Separate counter for conversation messages

    def log_message(self, message_type: str, content: str):
        """Log a message with timestamp and run ID."""
        timestamp = datetime.datetime.now(datetime.UTC).isoformat()
        log_entry = {
            "timestamp": timestamp,
            "run_id": self.run_id,
            "type": message_type,
            "content": content,
        }
        self.transcript_log.append(log_entry)
        # Print directly to console with run ID
        console.print(
            f"[bold cyan]{self.run_id}[/bold cyan] [blue]{message_type}:[/blue] {escape(content[:300])}"
        )

        # Stream message if streaming is enabled and it's a conversation message
        if self.streamer and self.evaluation_id and self.rollout_id:
            # Map message type to OpenAI role
            role = self._map_message_type_to_role(message_type)

            # Only stream messages that have roles (actual conversation messages)
            if role is not None:
                message_data = {
                    "timestamp": timestamp,
                    "sequence_number": self.conversation_sequence,
                    "role": role,
                    "content": content,
                }

                self.conversation_sequence += 1

                # Create async task to stream message (fire and forget)
                asyncio.create_task(self._stream_message_async(message_data))

    def _map_message_type_to_role(self, message_type: str) -> Optional[str]:
        """Map apex-arena message types to OpenAI role format."""
        role_mapping = {
            "PROMPT": "user",
            "MODEL_TEXT": "assistant",
            "THINKING": "assistant",
            "TOOL_CALL": "assistant",
            "TOOL_RESULT": "tool",
            # Non-conversation messages don't have roles (will be filtered out)
            "SETUP": None,
            "MCP": None,
            "TOOLS": None,
            "TURN": None,
            "COMPLETE": None,
            "ERROR": None,
            "ANSWER": None,
            "NO_TOOLS": None,
            "RETRY": None,
            "EXCEPTION": None,
            "GRADE": None,
        }
        return role_mapping.get(message_type)

    async def _stream_message_async(self, message_data: Dict[str, Any]):
        """Async helper to stream a single message."""
        max_retries = 5
        retry = 0
        while retry < max_retries:
            try:
                await self.streamer.stream_messages(
                    self.evaluation_id, self.rollout_id, [message_data]
                )
                break
            except Exception as e:
                retry += 1
                # Don't let streaming errors crash the evaluation
                console.print(
                    f"[yellow]Warning: Failed to stream message (Attempt {retry}/{max_retries}): {type(e)}: {e}[/yellow]"
                )

    def save_transcript(self):
        """Save the complete transcript to file."""
        with open(self.transcript_file, "w") as f:
            json.dump(
                {
                    "run_id": self.run_id,
                    "model": self.model,
                    "max_tokens": self.max_tokens,
                    "transcript": self.transcript_log,
                },
                f,
                indent=2,
            )

    async def run_problem(self, problem_id: str) -> Dict[str, Any]:
        """Override to add logging."""
        self.log_message("SETUP", f"Starting problem: {problem_id}")

        try:
            result = await self._run_problem_with_logging(problem_id)
            self.log_message(
                "COMPLETE", f"Finished with grade: {result.get('grade_result', 'N/A')}"
            )
            return result
        except Exception as e:
            import traceback

            error_details = (
                f"Failed with error: {str(e)}\nTraceback: {traceback.format_exc()}"
            )
            self.log_message("ERROR", error_details)
            raise
        finally:
            self.save_transcript()

    async def _run_problem_with_logging(self, problem_id: str) -> Dict[str, Any]:
        """Run problem with detailed logging."""
        from mcp import ClientSession
        from mcp.client.streamable_http import streamablehttp_client

        from .utils import (
            mcp_content_block_to_messages_format,
            messages_to_raw_prompt,
        )

        # Connect to the streamable HTTP server with retries
        max_connection_retries = 5

        # Add a small initial delay to help with server readiness
        if max_connection_retries > 1:
            await asyncio.sleep(1)

        logger.debug(f"[DEBUG] {self.server_url}: running problem {problem_id}")

        for connection_attempt in range(max_connection_retries):
            try:
                async with streamablehttp_client(
                    self.server_url, timeout=timedelta(seconds=600), sse_read_timeout=timedelta(seconds=800)
                ) as (
                    read_stream,
                    write_stream,
                    _,
                ):
                    # Create a session using the client streams
                    async with ClientSession(read_stream, write_stream) as session:
                        # Initialize the connection
                        await session.initialize()
                        self.log_message("MCP", "Connected to MCP server")

                        # Setup the problem
                        setup_start = time.time()
                        setup_result = await session.call_tool(
                            "setup_problem", {"problem_id": problem_id}
                        )
                        setup_duration = time.time() - setup_start
                        logger.debug(
                            f"Setup problem call_tool completed in {setup_duration:.3f}s"
                        )
                        self.log_message("SETUP", "Problem setup completed")

                        # Get available tools
                        tools = await session.list_tools()
                        available_tools = [
                            {
                                "name": tool.name,
                                "description": tool.description,
                                "input_schema": tool.inputSchema,
                            }
                            for tool in tools.tools
                            if tool.name != "setup_problem"
                        ]

                        self.log_message(
                            "TOOLS",
                            f"Available tools: {[t['name'] for t in available_tools]}",
                        )

                        prompt = setup_result.content[0].text
                        self.log_message("PROMPT", f"Initial prompt: {prompt}")

                        messages = [{"role": "user", "content": prompt}]

                        conversation_turn = 0
                        while True:
                            for message in messages[:-2]:
                                if message["role"] == "assistant":
                                    for content in message["content"]:
                                        if (
                                            isinstance(content, dict)
                                            and content.get("type") == "tool_use"
                                        ):
                                            tool_use_content = content
                                            if "cache_control" in tool_use_content:
                                                tool_use_content["cache_control"] = None
                            if conversation_turn > self.max_turns:
                                self.log_message("ERROR", "Max turns reached, exiting")
                                grade_start = time.time()
                                grade = await session.call_tool(
                                    "grade_problem",
                                    {
                                        "transcript": messages_to_raw_prompt(
                                            "[system_prompt_placeholder]\n\n",
                                            messages,
                                        ),
                                        "problem_id": problem_id,
                                    },
                                )
                                grade_duration = time.time() - grade_start
                                logger.debug(
                                    f"Grade problem call_tool (max turns) completed in {grade_duration:.3f}s"
                                )
                                return {
                                    "problem_id": problem_id,
                                    "grade_result": grade.content[0].text,
                                }

                            conversation_turn += 1
                            self.log_message(
                                "TURN",
                                f"Starting conversation turn {conversation_turn}",
                            )

                            # Retry logic for rate limiting
                            max_retries = 10
                            for attempt in range(max_retries + 1):
                                try:
                                    create_message_start = time.time()
                                    response = await self.proxy.create_message(
                                        model=self.model,
                                        messages=messages,
                                        max_tokens=self.max_tokens,
                                        tools=available_tools,
                                    )
                                    create_message_duration = (
                                        time.time() - create_message_start
                                    )
                                    logger.debug(
                                        f"Create message completed in {create_message_duration:.3f}s"
                                    )
                                    break  # Success, exit retry loop
                                except Exception as e:
                                    if attempt < max_retries and 'budget' not in str(e).lower() and 'invalid api' not in str(e).lower():
                                        # Exponential backoff: 2^attempt seconds
                                        delay = min(2**attempt, 30)
                                        await asyncio.sleep(delay)
                                        self.log_message(
                                            "RETRY",
                                            f"Retrying ({attempt}/{max_retries}). error: {e}",
                                        )
                                        continue
                                    else:
                                        self.log_message(
                                            "ERROR",
                                            f"Errored out after {max_retries} retries. error: {e}",
                                        )
                                        raise

                            if not response.get("content"):
                                self.log_message(
                                    "ERROR", "No response content from model"
                                )
                                return {
                                    "problem_id": problem_id,
                                    "grade_result": {
                                        "subscores": {"initial": 0.0},
                                        "weights": {"initial": 1.0},
                                        "metadata": {
                                            "feedback": "Agent might have not called grade_problem tool call!"
                                        },
                                    },
                                }

                            assistant_content = []
                            tool_results = []
                            has_tool_call = False
                            tool_call_idx = []

                            for idx, content in enumerate(response["content"]):
                                if content["type"] == "tool_use":
                                    tool_call_idx.append(idx)

                            for idx, content in enumerate(response["content"]):
                                if content["type"] == "tool_use":
                                    has_tool_call = True
                                    tool_name = content["name"]
                                    tool_args = content["input"]
                                    tool_id = content["id"]

                                    self.log_message(
                                        "TOOL_CALL", f"{tool_name}: {tool_args}"
                                    )

                                    if tool_name == "grade_problem":
                                        tool_start = time.time()
                                        tool_result = await session.call_tool(
                                            tool_name, tool_args
                                        )
                                        tool_duration = time.time() - tool_start
                                        logger.debug(
                                            f"Grade problem call_tool completed in {tool_duration:.3f}s"
                                        )
                                        self.log_message(
                                            "GRADE", "Problem graded successfully"
                                        )
                                        return {
                                            "problem_id": problem_id,
                                            "grade_result": tool_result.content[0].text,
                                        }

                                    tool_start = time.time()
                                    tool_result = await session.call_tool(
                                        tool_name, tool_args
                                    )
                                    tool_duration = time.time() - tool_start
                                    logger.debug(
                                        f"Tool {tool_name} call_tool completed in {tool_duration:.3f}s"
                                    )
                                    self.log_message(
                                        "TOOL_RESULT",
                                        str(tool_result),
                                    )

                                    if "text" in content and content["text"]:
                                        assistant_content.append(
                                            {"type": "text", "text": content["text"]}
                                        )
                                    assistant_content.append(
                                        {
                                            "type": "tool_use",
                                            "id": content["id"],
                                            "name": content["name"],
                                            "input": content["input"],
                                            "cache_control": {"type": "ephemeral"}
                                            if idx == tool_call_idx[-1]
                                            else None,
                                        }
                                    )
                                    tool_results.append(
                                        {
                                            "type": "tool_result",
                                            "is_error": tool_result.isError,
                                            "tool_use_id": tool_id,
                                            "content": [
                                                mcp_content_block_to_messages_format(
                                                    content
                                                )
                                                for content in tool_result.content
                                            ],
                                        }
                                    )
                                elif content["type"] == "text":
                                    self.log_message(
                                        "MODEL_TEXT",
                                        content["text"],
                                    )

                                    if (
                                        "<answer>" in content["text"]
                                        and "</answer>" in content["text"]
                                    ) or ("<DONE>" in content["text"]):
                                        logger.debug(
                                            f"[DEBUG] {self.server_url}: found answer. finished problem {problem_id}"
                                        )
                                        self.log_message(
                                            "ANSWER",
                                            "Found answer tags in model response",
                                        )
                                        grade_start = time.time()
                                        grade = await session.call_tool(
                                            "grade_problem",
                                            {
                                                "transcript": messages_to_raw_prompt(
                                                    "[system_prompt_placeholder]\n\n",
                                                    messages,
                                                ),
                                                "problem_id": problem_id,
                                            },
                                        )
                                        grade_duration = time.time() - grade_start
                                        logger.debug(
                                            f"Grade problem call_tool (answer found) completed in {grade_duration:.3f}s"
                                        )
                                        return {
                                            "problem_id": problem_id,
                                            "grade_result": grade.content[0].text,
                                        }

                                    assistant_content.append(
                                        {"type": "text", "text": content["text"]}
                                    )
                                elif content["type"] == "thinking":
                                    self.log_message(
                                        "THINKING",
                                        f"Thinking: {content['thinking']}",
                                    )
                                    assistant_content.append(content)

                            messages.append(
                                {"role": "assistant", "content": assistant_content}
                            )
                            if not has_tool_call:
                                self.log_message(
                                    "NO_TOOLS",
                                    "No tool calls in response, grading final state",
                                )
                                grade_start = time.time()
                                grade = await session.call_tool(
                                    "grade_problem",
                                    {
                                        "transcript": messages_to_raw_prompt(
                                            "[system_prompt_placeholder]\n\n", messages
                                        ),
                                        "problem_id": problem_id,
                                    },
                                )
                                grade_duration = time.time() - grade_start
                                logger.debug(
                                    f"Grade problem call_tool (no tools) completed in {grade_duration:.3f}s"
                                )
                                logger.debug(
                                    f"[DEBUG] {self.server_url}: no tool call. finished problem {problem_id}"
                                )
                                return {
                                    "problem_id": problem_id,
                                    "grade_result": grade.content[0].text,
                                }
                            else:
                                messages.append(
                                    {
                                        "role": "user",
                                        "content": tool_results,
                                    }
                                )

            except Exception as e:
                if connection_attempt < max_connection_retries - 1:
                    self.log_message(
                        "RETRY",
                        f"{self.server_url}: MCP error (attempt {connection_attempt + 1}/{max_connection_retries}): {str(e)}, {type(e)}.",
                    )
                    print("=== MCP error===")
                    traceback.print_exception(e)
                    await asyncio.sleep(5)
                    continue
                else:
                    self.log_message(
                        "ERROR",
                        f"MCP connection failed after {max_connection_retries} attempts. Root error: {str(e)}",
                    )
                    print("=== MCP error===")
                    traceback.print_exception(e)
                    raise

        # This should never be reached due to break/raise above, but just in case
        raise RuntimeError("Unexpected end of retry loop")


class ProgressManager:
    def __init__(self, use_live: bool = True):
        self.progress = None
        self.task_id = None
        self.live = None
        self.use_live = use_live

    def start_progress(self, total: int):
        self.progress = Progress()
        self.task_id = self.progress.add_task(
            "[green]Running evaluations...", total=total
        )

        if self.use_live:
            # Use Live to pin the progress bar at the top
            self.live = Live(self.progress, console=console, refresh_per_second=4)
            self.live.start()
        else:
            # Simple progress bar for debugging
            self.progress.start()

    def update_progress(self, advance: int = 1):
        if self.progress and self.task_id is not None:
            self.progress.update(self.task_id, advance=advance)

    def stop_progress(self):
        if self.live:
            self.live.stop()
        elif self.progress:
            self.progress.stop()


# Global progress manager for the evaluation
eval_progress = ProgressManager()


@dataclass
class EvalResult:
    task: str
    run: int
    grade_result: Any
    duration: float
    success: bool
    error: Optional[str] = None
    transcript_file: Optional[str] = None
    server_log_file: Optional[str] = None


@dataclass
class AggregatedResult:
    task: str
    mean_score: float
    std_dev: float
    success_rate: float
    total_runs: int
    scores: List[float]


def _allocate_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))  # 0 ⇒ “pick any free port”
        return s.getsockname()[1]


class DockerManager:
    def __init__(self):
        self.running_containers: Set[str] = set()
        self.client = httpx.Client(timeout=10.0)

    def wait_for_server_ready(self, server_url: str, max_attempts: int = 10) -> bool:
        """Wait for MCP server to be ready by making health check requests."""

        attempt = 0

        while attempt < max_attempts:
            attempt += 1
            try:
                logger.debug(f"[DEBUG]: Sending health check request to {server_url}")
                # Try a simple GET request to the MCP server URL
                response = self.client.get(server_url)
                logger.debug(f"[DEBUG]: Got response {response} from {server_url}")
                if response.status_code in [
                    200,
                    404,
                    405,
                    406,
                    307
                ]:  # Any valid HTTP response means server is up
                    console.print(
                        f"[green]✓ Server ready at {server_url} (attempt {attempt})[/green]"
                    )
                    return True
            except Exception as e:
                # Server not ready yet, continue waiting
                console.print(
                    f"[dim]Server not ready yet at {server_url} (attempt {attempt}): error: {str(e)[:100]}...[/dim]"
                )
            time.sleep(5)

        console.print(
            f"[red]✗ Server failed to become ready at {server_url} after {max_attempts} attempts[/red]"
        )
        return False

    def start_container(
        self,
        task: str,
        run: int,
        port: int,
        server_log_file: Path,
        image_name: Optional[str] = None,
    ) -> str:
        """Start a Docker container for the task and return container name."""
        timestamp = int(time.time())
        container_name = f"apex-arena-eval-{task}-{run}-{timestamp}"

        assert image_name is not None, "Image name is required"

        # Create the log file if it doesn't exist
        server_log_file.touch()

        cmd = [
            "docker",
            "run",
            "-d",
            "--rm",
            "--name",
            container_name,
            "--network",
            "restricted_net",
            "--cpus",
            "4",
            "-p",
            f"{port}:8001",
            "-v",
            f"{Path.cwd()}/tasks:/mcp_server/tasks",
            "-v",
            f"{server_log_file.parent.absolute()}:/mcp_server/logs",
            "-e",
            "MCP_TESTING_MODE=1",
            image_name,
            "sh",
            "-c",
            f"python3 /mcp_server/apex_arena/server.py > /mcp_server/logs/{server_log_file.name} 2>&1",
        ]

        logger.debug(f"[DEBUG] Starting container {image_name}")

        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(f"Failed to start container: {result.stderr}")
        self.running_containers.add(container_name)

        # Wait for MCP server to be ready with health check
        server_url = f"http://localhost:{port}/mcp"
        logger.debug(f"[DEBUG] {server_url}: Waiting for server ready")

        server_ready = self.wait_for_server_ready(server_url)
        logger.debug(f"[DEBUG] {server_url}: Server is ready")

        if not server_ready:
            # Clean up the container if server never became ready
            self.stop_container(container_name)
            raise RuntimeError(
                f"{server_url}: MCP server failed to start within 30 seconds"
            )

        return container_name

    def stop_container(self, container_name: str):
        """Stop and remove a Docker container."""
        try:
            subprocess.run(
                ["docker", "rm", "-f", container_name], capture_output=True, text=True
            )
        except Exception as e:
            console.print(
                f"[yellow]Warning: Failed to stop container {container_name}: {e}[/yellow]"
            )
        finally:
            self.running_containers.discard(container_name)

    def cleanup_all(self):
        """Stop all running containers."""
        for container in self.running_containers:
            self.stop_container(container)


class EvalRunner:
    def __init__(
        self,
        model: str = "smallie",
        max_tokens: int = 1000,
        max_concurrency: int = 3,
        transcript_dir: str = "eval_transcripts",
        debug_mode: bool = False,
        max_turns: int = 50,
        # New streaming parameters
        stream_results: bool = False,
        apex_server_url: Optional[str] = None,
        apex_api_key: Optional[str] = None,
    ):
        self.model = model
        self.max_tokens = max_tokens
        self.max_concurrency = max_concurrency
        self.transcript_dir = Path(transcript_dir)
        self.transcript_dir.mkdir(exist_ok=True)
        # Create server logs directory
        self.server_logs_dir = self.transcript_dir / "server_logs"
        self.server_logs_dir.mkdir(exist_ok=True)
        self.debug_mode = debug_mode
        self.max_turns = max_turns
        self.docker_manager = DockerManager()
        self.semaphore = asyncio.Semaphore(max_concurrency)

        # New streaming configuration
        self.stream_results = stream_results
        self.apex_server_url = apex_server_url
        self.apex_api_key = apex_api_key

        self.executor = ThreadPoolExecutor(max_workers=os.cpu_count() - 1)
        # Validate streaming configuration
        if self.stream_results:
            if not self.apex_server_url:
                raise ValueError("apex_server_url is required when stream_results=True")
            if not self.apex_api_key:
                raise ValueError("apex_api_key is required when stream_results=True")

        # Ensure the restricted network exists
        from .cli import create_restricted_network

        create_restricted_network()

    def discover_tasks(self, tasks_dir: Path = None) -> List[str]:
        """Discover all valid tasks in the tasks directory."""
        if tasks_dir is None:
            # Import here to avoid circular imports
            import os

            tasks_dir_str = os.getenv("APEX_TASK_DIR", "tasks")
            tasks_dir = Path(tasks_dir_str).resolve()

        valid_tasks = []
        if not tasks_dir.exists():
            console.print(
                f"[yellow]Tasks directory {tasks_dir} does not exist[/yellow]"
            )
            return valid_tasks

        for task_path in tasks_dir.iterdir():
            if task_path.is_dir():
                task_yaml = task_path / "task.yaml"
                grader_py = task_path / "grader.py"

                if task_yaml.exists() and grader_py.exists():
                    valid_tasks.append(task_path.name)
                else:
                    console.print(
                        f"[yellow]Skipping {task_path.name}: missing task.yaml or grader.py[/yellow]"
                    )

        return sorted(valid_tasks)

    async def run_single_evaluation(
        self,
        task: str,
        run: int,
        streamer: Optional[ResultStreamer] = None,
        evaluation_id: Optional[str] = None,
        image_name: Optional[str] = None,
    ) -> EvalResult:
        """Run a single evaluation for a task."""
        # Create transcript file
        run_id = f"{task}-run{run}"
        transcript_file = self.transcript_dir / f"{run_id}.json"

        # Create server log file path (will be mounted into container)
        server_log_file = self.server_logs_dir / f"{run_id}-server.log"

        # Container startup retry logic
        max_container_retries = 3
        container_name = None
        port = None
        start_time = time.time()

        for container_attempt in range(max_container_retries):
            try:
                try:
                    port = _allocate_port()
                    # Try to start container and wait for it to be ready
                    loop = asyncio.get_event_loop()
                    container_name = await loop.run_in_executor(
                        self.executor,
                        lambda: self.docker_manager.start_container(
                            task, run, port, server_log_file, image_name
                        ),
                    )

                    # If we get here, container started successfully
                    console.print(
                        f"[green]✓ Container started successfully: {container_name}[/green]"
                    )
                    break  # Success, exit container retry loop

                except Exception as container_error:
                    # Container startup failed
                    if container_attempt < max_container_retries - 1:
                        console.print(
                            f"[yellow]⚠ Container startup failed (attempt {container_attempt + 1}/{max_container_retries}): {str(container_error)}[/yellow]"
                        )
                        console.print(
                            "[yellow]  Retrying with new container and port...[/yellow]"
                        )

                        # Clean up failed container if it exists
                        if container_name:
                            self.docker_manager.stop_container(container_name)
                            container_name = None

                        # Release current port
                        port = None

                        # Wait before retrying
                        await asyncio.sleep(2)
                        continue
                    else:
                        # Final attempt failed
                        console.print(
                            f"[red]✗ Container startup failed after {max_container_retries} attempts: {str(container_error)}[/red]"
                        )
                        raise

            except Exception as e:
                # Clean up on any error
                if container_name:
                    self.docker_manager.stop_container(container_name)
                raise e

        # At this point, we should have a running container
        if not container_name or not port:
            raise RuntimeError("Failed to start container after all retries")

        try:
            # Stream rollout start if streaming is enabled
            rollout_id = None
            if streamer and evaluation_id:
                try:
                    rollout_id = await streamer.stream_rollout(
                        evaluation_id=evaluation_id,
                        local_task_id=task,
                        run_number=run,
                        success=False,  # Will update to True on success
                    )
                except Exception as e:
                    console.print(
                        f"[yellow]Warning: Failed to start rollout streaming: {type(e)}: {e}[/yellow]"
                    )

            server_url = f"http://localhost:{port}/mcp"
            client = LoggingApexArenaClient(
                server_url,
                self.model,
                self.max_tokens,
                run_id,
                transcript_file,
                self.max_turns,
                # Streaming parameters
                streamer=streamer,
                evaluation_id=evaluation_id,
                rollout_id=rollout_id,
            )

            result = await client.run_problem(task)
            duration = time.time() - start_time

            # Stream final rollout result if streaming is enabled
            if streamer and evaluation_id:
                try:
                    extracted_score = extract_score_from_grade_result(
                        result["grade_result"]
                    )
                    await streamer.stream_rollout(
                        evaluation_id=evaluation_id,
                        local_task_id=task,
                        run_number=run,
                        success=True,
                        grade_result=result["grade_result"],
                        extracted_score=extracted_score,
                    )
                except Exception as e:
                    console.print(
                        f"[yellow]Warning: Failed to stream final rollout: {e}[/yellow]"
                    )

            return EvalResult(
                task=task,
                run=run,
                grade_result=result["grade_result"],
                duration=duration,
                success=True,
                transcript_file=str(transcript_file),
                server_log_file=str(server_log_file),
            )

        except Exception as e:
            duration = time.time() - start_time
            return EvalResult(
                task=task,
                run=run,
                grade_result=None,
                duration=duration,
                success=False,
                error=str(e),
                transcript_file=str(transcript_file)
                if transcript_file.exists()
                else None,
                server_log_file=str(server_log_file)
                if server_log_file.exists()
                else None,
            )
        finally:
            if container_name:
                self.docker_manager.stop_container(container_name)

    def extract_score(self, grade_result: Any) -> float:
        """Extract numerical score from grade result."""
        try:
            if isinstance(grade_result, str):
                # Try to parse as JSON
                grade_data = json.loads(grade_result)
            else:
                grade_data = grade_result

            if isinstance(grade_data, dict):
                if "subscores" in grade_data and "weights" in grade_data:
                    # Calculate weighted score
                    subscores = grade_data["subscores"]
                    weights = grade_data["weights"]
                    total_score = sum(
                        subscores[key] * weights[key] for key in subscores.keys()
                    )
                    return total_score
                elif "score" in grade_data:
                    return float(grade_data["score"])

            # If it's already a number
            if isinstance(grade_data, (int, float)):
                return float(grade_data)

            return 0.0
        except Exception:
            return 0.0

    def aggregate_results(
        self, results: List[EvalResult]
    ) -> Dict[str, AggregatedResult]:
        """Aggregate results by task."""
        task_results = {}

        for task in set(r.task for r in results):
            task_evals = [r for r in results if r.task == task]
            successful_evals = [r for r in task_evals if r.success]

            if successful_evals:
                scores = [self.extract_score(r.grade_result) for r in successful_evals]
                mean_score = statistics.mean(scores)
                std_dev = statistics.stdev(scores) if len(scores) > 1 else 0.0
            else:
                scores = []
                mean_score = 0.0
                std_dev = 0.0

            success_rate = len(successful_evals) / len(task_evals)

            task_results[task] = AggregatedResult(
                task=task,
                mean_score=mean_score,
                std_dev=std_dev,
                success_rate=success_rate,
                total_runs=len(task_evals),
                scores=scores,
            )

        return task_results

    async def run_evaluation(
        self, tasks: List[str], runs: int, force_build: bool = False
    ) -> Dict[str, Any]:
        """Run full evaluation across tasks and runs."""
        console.print(
            f"[green]Starting evaluation: {len(tasks)} tasks × {runs} runs = {len(tasks) * runs} total evaluations[/green]"
        )
        console.print(f"[blue]Max concurrency: {self.max_concurrency}[/blue]")

        # Initialize streaming if enabled
        streamer = None
        evaluation_id = None

        if self.stream_results:
            console.print(f"[cyan]Streaming results to: {self.apex_server_url}[/cyan]")
            try:
                streamer = ResultStreamer(self.apex_server_url, self.apex_api_key)

                evaluation_id = await streamer.start_evaluation(
                    tasks=tasks,
                    runs_per_task=runs,
                    model=self.model,
                    max_tokens=self.max_tokens,
                    max_concurrency=self.max_concurrency,
                )
                console.print(
                    f"[green]Started remote evaluation: {evaluation_id}[/green]"
                )
            except Exception as e:
                console.print(f"[red]Failed to initialize streaming: {e}[/red]")
                console.print(
                    "[yellow]Continuing with local evaluation only...[/yellow]"
                )
                streamer = None
                evaluation_id = None

        # Check for existing apex-arena containers
        existing_containers_result = subprocess.run(
            [
                "docker",
                "ps",
                "-a",
                "--filter",
                "name=apex-arena",
                "--format",
                "{{.Names}}",
            ],
            capture_output=True,
            text=True,
        )
        existing_containers = [
            name.strip()
            for name in existing_containers_result.stdout.split("\n")
            if name.strip()
        ]

        if existing_containers:
            console.print(
                f"[yellow]Found existing apex-arena containers: {', '.join(existing_containers)}[/yellow]"
            )
            from rich.prompt import Confirm

            should_cleanup = Confirm.ask(
                "Clean up existing containers before starting evaluation?",
                default=False,
            )

            if should_cleanup:
                console.print("[yellow]Cleaning up existing containers...[/yellow]")
                result = subprocess.run(
                    ["docker", "rm", "-f"] + existing_containers,
                    capture_output=True,
                    text=True,
                )
                if result.stdout:
                    console.print(
                        f"[yellow]Removed containers: {result.stdout}[/yellow]"
                    )
            else:
                console.print("[blue]Keeping existing containers.[/blue]")

        console.print("[yellow]Building task images...[/yellow]")
        with tqdm(total=len(tasks)) as pbar:
            futs = []
            for task in tasks:
                fut = self.executor.submit(build_docker_image, task, force=force_build)
                futs.append(fut)

            for _ in concurrent.futures.as_completed(futs):
                pbar.update(1)

        # Create all evaluation tasks
        tasks_to_run = []

        async def run_with_semaphore(task, run, image_name):
            async with self.semaphore:
                result = await self.run_single_evaluation(
                    task, run, streamer, evaluation_id, image_name
                )
                return result

        for task in tasks:
            image_name = f"apex_arena:{task}"
            for run in range(1, runs + 1):
                tasks_to_run.append(run_with_semaphore(task, run, image_name))

        # Run all evaluations with progress tracking
        results = []

        # Set up progress manager based on debug mode
        global eval_progress
        eval_progress = ProgressManager(use_live=not self.debug_mode)

        eval_progress.start_progress(len(tasks_to_run))

        try:
            # Start all tasks and process them as they complete
            for completed_task in asyncio.as_completed(tasks_to_run):
                try:
                    result = await completed_task
                    results.append(result)

                    if result.success:
                        console.print(
                            f"[green]✓ COMPLETED[/green] {result.task} run {result.run}: {result.duration:.1f}s [dim]({result.transcript_file}) [yellow]server: {result.server_log_file}[/yellow][/dim]"
                        )
                    else:
                        console.print(
                            f"[red]✗ FAILED[/red] {result.task} run {result.run}: {result.error} [dim][yellow]server: {result.server_log_file}[/yellow][/dim]"
                        )

                except Exception as e:
                    console.print(
                        f"[red]Task failed with exception: {escape(str(e))}[/red]"
                    )

                eval_progress.update_progress()
        finally:
            eval_progress.stop_progress()

        # Aggregate results
        aggregated = self.aggregate_results(results)

        # Complete streaming if enabled
        if streamer and evaluation_id:
            try:
                success_count = sum(1 for r in results if r.success)
                if success_count == len(results):
                    await streamer.complete_evaluation(evaluation_id, "completed")
                else:
                    await streamer.complete_evaluation(
                        evaluation_id, "completed"
                    )  # Still completed even with some failures
                console.print(
                    f"[green]Completed remote evaluation: {evaluation_id}[/green]"
                )
            except Exception as e:
                console.print(
                    f"[yellow]Warning: Failed to complete remote evaluation: {e}[/yellow]"
                )

        # Create final results structure
        eval_results = {
            "metadata": {
                "timestamp": datetime.datetime.now(datetime.UTC).isoformat(),
                "model": self.model,
                "max_tokens": self.max_tokens,
                "max_concurrency": self.max_concurrency,
                "tasks": tasks,
                "runs_per_task": runs,
                "total_evaluations": len(results),
                "evaluation_id": evaluation_id,  # Include remote evaluation ID if available
            },
            "individual_results": [asdict(r) for r in results],
            "aggregated_results": {k: asdict(v) for k, v in aggregated.items()},
        }

        return eval_results

    async def cleanup(self):
        """Clean up resources."""
        self.docker_manager.cleanup_all()
        self.executor.shutdown()


@contextlib.asynccontextmanager
async def eval_runner_context(*args, **kwargs):
    """Context manager for EvalRunner with automatic cleanup."""
    runner = EvalRunner(*args, **kwargs)
    try:
        yield runner
    finally:
        await runner.cleanup()
